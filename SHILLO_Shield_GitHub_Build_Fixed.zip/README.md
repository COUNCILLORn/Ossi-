# SHILLO Shield — Android starter

This is a starter Android app with a basic suspicious-link checker and simple security guidance. It is not a full antivirus and does not scan other apps or guarantee detection of cyberattacks.

## Build an APK with GitHub Actions

1. Upload the **contents** of this folder to the root of a GitHub repository. The repository root should directly contain `app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, and `.github/`.
2. Ensure the workflow file is at `.github/workflows/android.yml` (the leading dot is required).
3. Open the repository's **Actions** tab and select **Build SHILLO Shield APK**. It should run after a push to `main`/`master`; you can also select **Run workflow**.
4. When the run succeeds, open it and download the `SHILLO-Shield-debug-APK` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
5. Android may ask you to allow installation from your browser or file manager. Only install APKs you built or trust.

## Notes

- This workflow uses `ubuntu-24.04` to avoid depending on the `ubuntu-latest` image migration and uses updated GitHub Actions versions.
- The workflow is designed for the project files to be at repository root. If you upload the whole `SHILLO_Shield` directory as a nested folder, the file verification step will fail.
- The workflow produces a debug APK for testing, not a signed release for Play Store distribution.
